/********************���ݳ�����**************************
STM32F103C8T6
LCD: 
IC: ST7789
***** PB5    RD
      PB6    WR
      PB7    DC
      PB8    RES
      PB9    CS
			PA0-PA7 DB0-DB7
******************************************************/
#include "stm32f10x.h"
#include "led.h"
#include "key.h"  
#include "bmp.h"  

/**********SPI���ŷ��䣬����TFT��������ʵ������޸�*********/

#define TFT_COLUMN_NUMBER 170
#define TFT_LINE_NUMBER 320

#define TFT_COLUMN_OFFSET 0
#define TFT_LINE_OFFSET 0
#define USE_HORIZONTAL 0  //���ú�������������ʾ 0��1Ϊ���� 2��3Ϊ����


/**********SPI���ŷ��䣬����TFT��������ʵ������޸�*********/
#define DATAOUT(x) GPIOA->ODR=x; //
#define DATAIN     GPIOA->IDR;   //


#define LCD_RD_Clr() GPIO_ResetBits(GPIOB,GPIO_Pin_5)//RD
#define LCD_RD_Set() GPIO_SetBits(GPIOB,GPIO_Pin_5)

#define LCD_WR_Clr() GPIO_ResetBits(GPIOB,GPIO_Pin_6)//WR
#define LCD_WR_Set() GPIO_SetBits(GPIOB,GPIO_Pin_6)

#define LCD_DC_Clr()  GPIO_ResetBits(GPIOB,GPIO_Pin_7)//DC
#define LCD_DC_Set()  GPIO_SetBits(GPIOB,GPIO_Pin_7)

#define LCD_RES_Clr()   GPIO_ResetBits(GPIOB,GPIO_Pin_8)//RES
#define LCD_RES_Set()   GPIO_SetBits(GPIOB,GPIO_Pin_8)
 		     
#define LCD_CS_Clr()   GPIO_ResetBits(GPIOB,GPIO_Pin_9)//CS
#define LCD_CS_Set()   GPIO_SetBits(GPIOB,GPIO_Pin_9)


/*****************��ɫ����**************************/
#define WHITE         	 0xFFFF
#define BLACK         	 0x0000	  
#define BLUE           	 0x001F  
#define BRED             0XF81F
#define GRED 			       0XFFE0
#define GBLUE			       0X07FF
#define RED           	 0xF800
#define MAGENTA       	 0xF81F
#define GREEN         	 0x07E0
#define CYAN          	 0x7FFF
#define YELLOW        	 0xFFE0
#define BROWN 			     0XBC40 //��ɫ
#define BRRED 			     0XFC07 //�غ�ɫ
#define GRAY  			     0X8430 //��ɫ
#define DARKBLUE      	 0X01CF	//����ɫ
#define LIGHTBLUE      	 0X7D7C	//ǳ��ɫ  
#define GRAYBLUE       	 0X5458 //����ɫ
#define LIGHTGREEN     	 0X841F //ǳ��ɫ
#define LGRAY 			     0XC618 //ǳ��ɫ(PANNEL),���屳��ɫ
#define LGRAYBLUE        0XA651 //ǳ����ɫ(�м����ɫ)
#define LBBLUE           0X2B12 //ǳ����ɫ(ѡ����Ŀ�ķ�ɫ)


unsigned int page = 0;
unsigned int autoplay = 0;



void SYS_init(unsigned char PLL)
{
	
		 
	RCC->APB1RSTR = 0x00000000;//��λ����			 
	RCC->APB2RSTR = 0x00000000; 	  
  RCC->AHBENR = 0x00000014;  //˯��ģʽ�����SRAMʱ��ʹ��.�����ر�.	  
  RCC->APB2ENR = 0x00000000; //����ʱ�ӹر�.			   
  RCC->APB1ENR = 0x00000000;   
	RCC->CR |= 0x00000001;     //ʹ���ڲ�����ʱ��HSION
	
	RCC->CFGR &= 0xF8FF0000;   //��λSW[1:0],HPRE[3:0],PPRE1[2:0],PPRE2[2:0],ADCPRE[1:0],MCO[2:0]					 
	RCC->CR &= 0xFEF6FFFF;     //��λHSEON,CSSON,PLLON
	RCC->CR &= 0xFFFBFFFF;     //��λHSEBYP	   	  
	RCC->CFGR &= 0xFF80FFFF;   //��λPLLSRC, PLLXTPRE, PLLMUL[3:0] and USBPRE
	while(((RCC->CFGR>>2)& 0x03 )!=0x00); 	
	RCC->CIR = 0x00000000;     //�ر������ж�		 
	//����������				  
  
//	SCB->VTOR = 0x08000000|(0x0 & (u32)0x1FFFFF80);//����NVIC��������ƫ�ƼĴ���
	
 	RCC->CR|=0x00010000;  //�ⲿ����ʱ��ʹ��HSEON
	while(((RCC->CR>>17)&0x00000001)==0);//�ȴ��ⲿʱ�Ӿ���
	RCC->CFGR=0X00000400; //APB1=DIV2;APB2=DIV1;AHB=DIV1;
	PLL-=2;//����2����λ
	RCC->CFGR|=PLL<<18;   //����PLLֵ 2~16
	RCC->CFGR|=1<<16;	  //PLLSRC ON 
	

	RCC->CR|=0x01000000;  //PLLON
	while(!(RCC->CR>>25));//�ȴ�PLL����
	RCC->CFGR|=0x00000002;//PLL��Ϊϵͳʱ��	 
	while(((RCC->CFGR>>2)&0x03)!=0x02);   //�ȴ�PLL��Ϊϵͳʱ�����óɹ�
	
	
}

void IO_init(void)
{

	RCC->APB2ENR|=1<<2;    //??PORTA??
	RCC->APB2ENR|=1<<3;    //??PORTB?? 
	RCC->APB2ENR|=1<<4;    //??PORTC??

	GPIOB->CRL&=  0X00000000;				//?B34567??????????,??50MH
	GPIOB->CRL|=0X33333000;				
	GPIOB->CRH&=0X00000000;				//?PB??????????,??50MH
	GPIOB->CRH|=0X33333333;
	GPIOB->ODR=0XFFFF;
	
	GPIOA->CRL&=0X00000000;				//?PA??????????,??50MH
	GPIOA->CRL|=0X33333333;				
	
	GPIOC->CRH&=0X00000000;				//?PA??????????,??50MH
	GPIOC->CRH|=0X33300000;
	
	GPIOA->ODR=0XFFFF;
}
void delay_us(unsigned int _us_time)
{       
  unsigned char x=0;
  for(;_us_time>0;_us_time--)
  {
    x++;x++;x++;x++;x++;x++;x++;x++;x++;x++;x++;x++;
	  x++;x++;x++;x++;x++;x++;x++;x++;x++;x++;x++;x++;
  }
}
void delay_ms(unsigned int _ms_time)
  {
    unsigned int i,j;
    for(i=0;i<_ms_time;i++)
    {
    for(j=0;j<900;j++)
      {;}
    }
  }

	
	


/******************************************************************************
      ����˵����LCD��������д�뺯��
      ������ݣ�dat  Ҫд��Ĵ�������
      ����ֵ��  ��
******************************************************************************/
void LCD_Writ_Bus(u8 dat) 
{	
	LCD_CS_Clr();
	LCD_RD_Set();
	LCD_WR_Clr();
	DATAOUT(dat);
	LCD_WR_Set();
	LCD_CS_Set();
}


void LCD_GPIO_Init(void)
{
	GPIO_InitTypeDef  GPIO_InitStructure;
 	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);	 //ʹ��B�˿�ʱ��
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_4|GPIO_Pin_5|GPIO_Pin_6|GPIO_Pin_7|GPIO_Pin_8|GPIO_Pin_9;	 
 	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP; 		 //�������
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;//�ٶ�50MHz
 	GPIO_Init(GPIOB, &GPIO_InitStructure);	  //��ʼ��GPIOB
 	GPIO_SetBits(GPIOB,GPIO_Pin_4|GPIO_Pin_5|GPIO_Pin_6|GPIO_Pin_7|GPIO_Pin_8|GPIO_Pin_9);
}


/******************************************************************************
      ����˵����LCDд������
      ������ݣ�dat д�������
      ����ֵ��  ��
******************************************************************************/
void LCD_WR_DATA8(u8 dat)
{
	LCD_DC_Set();
	LCD_Writ_Bus(dat);
}


/******************************************************************************
      ����˵����LCDд������
      ������ݣ�dat д�������
      ����ֵ��  ��
******************************************************************************/
void LCD_WR_DATA(u16 dat)
{
	LCD_DC_Set();
	LCD_Writ_Bus(dat>>8);
	LCD_Writ_Bus(dat);
}


/******************************************************************************
      ����˵����LCDд������
      ������ݣ�dat д�������
      ����ֵ��  ��
******************************************************************************/
void LCD_WR_REG(u8 dat)
{
	LCD_DC_Clr();//д����
	LCD_Writ_Bus(dat);
	LCD_DC_Set();//д����
}


/******************************************************************************
      ����˵����������ʼ�ͽ�����ַ
      ������ݣ�x1,x2 �����е���ʼ�ͽ�����ַ
                y1,y2 �����е���ʼ�ͽ�����ַ
      ����ֵ��  ��
******************************************************************************/
void LCD_Address_Set(u16 x1,u16 y1,u16 x2,u16 y2)
{
		LCD_WR_REG(0x2a);//�е�ַ����
		LCD_WR_DATA(x1+35);
		LCD_WR_DATA(x2+35);
		LCD_WR_REG(0x2b);//�е�ַ����
		LCD_WR_DATA(y1);
		LCD_WR_DATA(y2);
		LCD_WR_REG(0x2c);//������д
}

/******************************************************************************
      ����˵����LCD��ʼ������
      ������ݣ���
      ����ֵ��  ��
******************************************************************************/
void LCD_Init(void)
{
 		 
		LCD_GPIO_Init();//��ʼ��GPIO
		LCD_RES_Set();
		delay_ms(10);	
		LCD_RES_Clr();//��λ
		delay_ms(10);
		LCD_RES_Set();
		delay_ms(120);


	LCD_WR_REG(0x11); 
	delay_ms(120); 
	LCD_WR_REG(0x36); 
	if(USE_HORIZONTAL==0)LCD_WR_DATA8(0x00);
	else if(USE_HORIZONTAL==1)LCD_WR_DATA8(0xC0);
	else if(USE_HORIZONTAL==2)LCD_WR_DATA8(0x70);
	else LCD_WR_DATA8(0xA0);

	LCD_WR_REG(0x3A);
	LCD_WR_DATA8(0x05);

		LCD_WR_REG(0xB2);     
		LCD_WR_DATA8(0x05);   
		LCD_WR_DATA8(0x05);   
		LCD_WR_DATA8(0x00);   
		LCD_WR_DATA8(0x33);   
		LCD_WR_DATA8(0x33);   

		LCD_WR_REG(0xB7);     
		LCD_WR_DATA8(0x35);   


		LCD_WR_REG(0xBB);     
		LCD_WR_DATA8(0x21);   

		LCD_WR_REG(0xC0);     
		LCD_WR_DATA8(0x2C);   

		LCD_WR_REG(0xC2);     
		LCD_WR_DATA8(0x01);   

		LCD_WR_REG(0xC3);     
		LCD_WR_DATA8(0x0B);   

		LCD_WR_REG(0xC4);     
		LCD_WR_DATA8(0x20);   

		LCD_WR_REG(0xC6);     
		LCD_WR_DATA8(0x0F);   //60HZ dot inversion

		LCD_WR_REG(0xD0);     
		LCD_WR_DATA8(0xA7);   
		LCD_WR_DATA8(0xA1); 

		LCD_WR_REG(0xD0);     
		LCD_WR_DATA8(0xA4);   
		LCD_WR_DATA8(0xA1);   
			

		LCD_WR_REG(0xD6);     
		LCD_WR_DATA8(0xA1);   

		LCD_WR_REG(0xE0);     
		LCD_WR_DATA8(0xD0);   
		LCD_WR_DATA8(0x04);   
		LCD_WR_DATA8(0x08);   
		LCD_WR_DATA8(0x0A);   
		LCD_WR_DATA8(0x09);   
		LCD_WR_DATA8(0x05);   
		LCD_WR_DATA8(0x2D);   
		LCD_WR_DATA8(0x43);   
		LCD_WR_DATA8(0x49);   
		LCD_WR_DATA8(0x09);   
		LCD_WR_DATA8(0x16);   
		LCD_WR_DATA8(0x15);   
		LCD_WR_DATA8(0x26);   
		LCD_WR_DATA8(0x2B);   

		LCD_WR_REG(0xE1);     
		LCD_WR_DATA8(0xD0);   
		LCD_WR_DATA8(0x03);   
		LCD_WR_DATA8(0x09);   
		LCD_WR_DATA8(0x0A);   
		LCD_WR_DATA8(0x0A);   
		LCD_WR_DATA8(0x06);   
		LCD_WR_DATA8(0x2E);   
		LCD_WR_DATA8(0x44);   
		LCD_WR_DATA8(0x40);   
		LCD_WR_DATA8(0x3A);   
		LCD_WR_DATA8(0x15);   
		LCD_WR_DATA8(0x15);   
		LCD_WR_DATA8(0x26);   
		LCD_WR_DATA8(0x2A);   

		LCD_WR_REG(0x21);    
		
		LCD_WR_REG(0x29);     
}

void Picture_display2()
{
	unsigned int i = 0;
	unsigned int j = 0;
	unsigned int a = 0;
	
	LCD_Address_Set(0,0,TFT_COLUMN_NUMBER-1,TFT_LINE_NUMBER-1);

		for(i=0;i<80;i++)
		{
			a = 0;
			for(j=0;j<240;j++)
			{
				LCD_Writ_Bus(gImage_r1[a]);
				a++;
				LCD_Writ_Bus(gImage_r1[a]);
				a++;
			}
		}
		
		a = 0;
		for(i=0;i<80;i++)
		{
			for(j=0;j<240;j++)
			{
				LCD_Writ_Bus(gImage_r1[a]);
				a++;
				LCD_Writ_Bus(gImage_r1[a]);
				a++;
			}
		}

		
		a = 0;
		for(i=0;i<80;i++)
		{
			for(j=0;j<240;j++)
			{
				LCD_Writ_Bus(gImage_r2[a]);
				a++;
				LCD_Writ_Bus(gImage_r2[a]);
				a++;
			}
		}

		
		a = 0;
		for(i=0;i<80;i++)
		{
			for(j=0;j<240;j++)
			{
				LCD_Writ_Bus(gImage_r3[a]);
				a++;
				LCD_Writ_Bus(gImage_r3[a]);
				a++;
			}
		}

		
}



void TFT_Page_1()
{
	int c = 0;
	int r = 0;

	int c2 = 0;
	int r2 = 0;

	int c3 = 0;
	int r3 = 0;

	for(r=0;r<TFT_LINE_NUMBER;r++)
	{
		for(c=0;c<TFT_COLUMN_NUMBER;c++)
		{
			c2 = (int)(c/45);
			r2 = (int)(r/40);
			c3 = c2 % 6;
			r3 = r2 % 8;

			if(r3 == 0){
				LCD_WR_DATA(WHITE);
			}else if(r3 == 1){
				LCD_WR_DATA(BLACK);
			}else if(r3 == 2){
				LCD_WR_DATA(RED);
			}else if(r3 == 3){
				LCD_WR_DATA(GREEN);
			}else if(r3 == 4){
				LCD_WR_DATA(BLUE);
			}else if(r3 == 5){
				LCD_WR_DATA(GBLUE);
			}else if(r3 == 6){
				LCD_WR_DATA(GRED);
			}else if(r3 == 7){
				LCD_WR_DATA(BRED);
			}
			
		}
	}
}
	


void TFT_Page_2()
{
	int c = 0;
	int r = 0;

	int c2 = 0;
	int r2 = 0;

	int c3 = 0;
	int r3 = 0;

	for(r=0;r<TFT_LINE_NUMBER;r++)
	{
		for(c=0;c<TFT_COLUMN_NUMBER;c++)
		{
			c2 = (int)(c/10);
			r2 = (int)(r/10);
			c3 = c2 % 2;
			r3 = r2 % 2;

			if(c3 == r3){
				LCD_WR_DATA(WHITE);
			}else{
				LCD_WR_DATA(BLACK);
			}			
		}
	}
}
/******************************************************************************
      ����˵������ָ�����������ɫ
      ������ݣ�xsta,ysta   ��ʼ����
                xend,yend   ��ֹ����
								color       Ҫ������ɫ
      ����ֵ��  ��
******************************************************************************/
void LCD_Fill(u16 xsta,u16 ysta,u16 xend,u16 yend,u16 color)
{          
	u16 i,j; 
	LCD_Address_Set(xsta,ysta,xend-1,yend-1);//������ʾ��Χ
	for(i=ysta;i<yend;i++)
	{													   	 	
		for(j=xsta;j<xend;j++)
		{
			LCD_WR_DATA(color);
		}
	} 					  	    
}	


void TFT_Page_border()
{
	int col = TFT_COLUMN_NUMBER;
	int row = TFT_LINE_NUMBER;
	
	int c, r;
	
	for(r=0;r<row;r++)
	{
		for(c=0;c<col;c++)
		{
			if(c==0 || r==0 || c == col-1 || r == row-1)
			{
				LCD_Writ_Bus(0xFF);
				LCD_Writ_Bus(0xFF);
			}else{
				LCD_Writ_Bus(0x00);
				LCD_Writ_Bus(0x00);
			}
			//delay_ms(50);
		}
	}
}
	



int main(void)
{
	delay_ms(100);
	
	SYS_init(8);
  IO_init();

	LCD_Init();//LCD��ʼ��

	int speeds = 5000;

	LED_GPIO_Config(); //LED �˿ڳ�ʼ��   	
  Key_GPIO_Config();//�����˿ڳ�ʼ��

//  Picture_display2();
//	return 0;

	page = 0;
	
  while(1)
  {
		if( Key_Scan(GPIOB,GPIO_Pin_12) == KEY_OFF  )	 //�ж�KEY1�Ƿ���
		{
			LED1( OFF );
			page++;
			if(page > 7){ page = 1; }
			if(page == 1){
				LCD_Fill(0,0,TFT_COLUMN_NUMBER,TFT_LINE_NUMBER, WHITE);
			}else if(page == 2){
				LCD_Fill(0,0,TFT_COLUMN_NUMBER,TFT_LINE_NUMBER, BLACK);
    		TFT_Page_border();
			}else if(page == 3){
				LCD_Fill(0,0,TFT_COLUMN_NUMBER,TFT_LINE_NUMBER, RED);
			}else if(page == 4){
				LCD_Fill(0,0,TFT_COLUMN_NUMBER,TFT_LINE_NUMBER, GREEN);
			}else if(page == 5){
				LCD_Fill(0,0,TFT_COLUMN_NUMBER,TFT_LINE_NUMBER, BLUE);
			}else if(page == 6){
		    TFT_Page_1();
			}else if(page == 7){
				TFT_Page_2();
//			}else if(page == 6){
//				Picture_display2();
			}else{
				page = 1;
			}
			delay_ms(speeds);
		}else{
			LED1( ON );
		}
	}		

}

